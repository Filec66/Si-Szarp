﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tego_typu
{
    internal class CreditOwner
    {
        private string creditOwnerName;
        private string creditOwnerSurname;
        private int credit;
        private int creditWorthiness;

        public CreditOwner(string creditOwnerName, string creditOwnerSurname, int credit, int creditWorthiness)
        {
            this.creditOwnerName = creditOwnerName;
            this.creditOwnerSurname = creditOwnerSurname;
            this.credit = credit;
            this.creditWorthiness = creditWorthiness;
        }

        public string getCreditOwnerName()
        {
            return this.creditOwnerName;
        }

        public string getCreditOwnerSurname()
        {
            return this.creditOwnerSurname;
        }

        public int getCredit()
        {
            return this.credit;
        }

        public int getCreditWorthiness()
        {
            return this.creditWorthiness;
        }

        public void showCreditOwner()
        {
            Console.WriteLine(this.getCreditOwnerName() + " " + this.getCreditOwnerSurname() + " " + this.getCredit() + " " + this.getCreditWorthiness());
        }

        public int sumCredit()
        {
            return this.getCredit() + this.getCreditWorthiness();
        }
    }
}
