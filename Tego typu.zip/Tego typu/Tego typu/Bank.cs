﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tego_typu
{
    internal class Bank
    {

        private string bankName;
        private string bankEmail;
        private int bankHotline;
        private bool isInPoland;

        public Bank(string bankName, string bankEmail, int bankHotline, bool isInPoland)
        {
            this.bankName = bankName;
            this.bankEmail = bankEmail;
            this.bankHotline = bankHotline;
            this.isInPoland = isInPoland;
        }

        public string getBankName()
        {
            return this.bankName;
        }

        public string getBankEmail()
        {
            return this.bankEmail;
        }

        public int getBankHotline()
        {
            return this.bankHotline;
        }

        public bool getIsInPoland()
        {
            return this.isInPoland;
        }
        public void showBank()
        {

            Console.WriteLine(this.getBankName() + " " + this.getBankEmail() + " " + this.getBankHotline() + " " + this.getIsInPoland());
        }

    }
}
