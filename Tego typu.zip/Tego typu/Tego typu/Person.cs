﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tego_typu
{
    internal class Person
    {
        private string name;
        private string surname;
        private int phoneNumber;
        private int age;

        public Person(string name, string surname, int phoneNumber, int age)
        {
            this.name = name;
            this.surname = surname;
            this.phoneNumber = phoneNumber;
            this.age = age;
        }

        public string getName()
        {
            return this.name;
        }

        public string getSurname()
        {
            return this.surname;
        }

        public int getPhoneNumber()
        {
            return this.phoneNumber;
        }

        public int getAge()
        {
            return this.age;
        }

        public void showPerson()
        {
            Console.WriteLine(this.getName() + " " + this.getSurname() + " " + this.getPhoneNumber() + " " + this.getAge());
        }

    }
}
