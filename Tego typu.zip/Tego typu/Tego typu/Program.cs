﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tego_typu
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person("Hank", "Hank", 542563664, 32);

            Bank bank = new Bank("OKAPE", "okape@gmail.com", 536844353, true);

            CreditOwner creditOwner = new CreditOwner("Hank", "Hank", 300000, 20000);

            person.showPerson();

            bank.showBank();

            creditOwner.showCreditOwner();

            Console.WriteLine(creditOwner.sumCredit());

            Console.ReadKey();
        }
    }
}
